// codeforces.js - New for Codeforces
const API_URL = "http://localhost:5000/api/solve";

const getProblemTitle = () => {
    const titleEl = document.querySelector(".problem-title") || document.querySelector("h1");
    return titleEl ? titleEl.textContent.trim() : null;
};

const getProblemSlug = () => {
    const match = window.location.pathname.match(/contest\/(\d+)\/problem\/(\w+)/);
    return match ? `${match[1]}-${match[2]}` : null;
};

const getHandle = () => {
    const profile = document.querySelector("a[href*='/profile/']");
    if (profile) {
        const match = profile.getAttribute("href").match(/profile\/([^/]+)/);
        return match ? match[1] : null;
    }
    return null;
};

const hasAccepted = () => {
    const bodyText = document.body?.innerText.toLowerCase() || "";
    return bodyText.includes("accepted") || bodyText.includes("solution accepted");
};

const hasAlreadySolved = () => {
    return document.body?.innerText.toLowerCase().includes("you have solved this problem") || false;
};

const updatePopup = (accepted) => {
    if (typeof chrome === "undefined" || !chrome.runtime) return;
    const payload = {
        platform: "Codeforces",
        questionTitle: getProblemTitle(),
        problemSlug: getProblemSlug(),
        detectedAt: new Date().toISOString(),
        accepted: Boolean(accepted)
    };
    try {
        chrome.runtime.sendMessage({ type: "UPDATE_POPUP", payload });
    } catch (e) { }
};

const sendSolve = async () => {
    const payload = {
        platform: "Codeforces",
        questionTitle: getProblemTitle(),
        problemSlug: getProblemSlug(),
        handle: getHandle(),
        accepted: true
    };

    if (!payload.questionTitle) return;

    updatePopup(true);

    const key = `cc_codeforces_${payload.problemSlug || payload.questionTitle}`;
    if (sessionStorage.getItem(key)) return;

    chrome.runtime.sendMessage({
        type: "SOLVE_DETECTED",
        payload
    });
    sessionStorage.setItem(key, "1");
};

let initialCheckDone = false;

setInterval(() => {
    const accepted = hasAccepted();
    const alreadySolved = !initialCheckDone && hasAlreadySolved();

    if (accepted || alreadySolved) {
        if (alreadySolved) {
            console.log("CodeCanon: Codeforces problem was already previously solved! Syncing retroactively.");
            initialCheckDone = true;
        } else {
            console.log("CodeCanon: Success detected in Codeforces from new submission!");
        }
        sendSolve();
    } else {
        if (getProblemSlug()) {
            updatePopup(false);
            if (document.readyState === "complete") {
                initialCheckDone = true;
            }
        }
    }
}, 2000);
