// atcoder.js - New for AtCoder
const API_URL = "http://localhost:5000/api/solve";

const getProblemTitle = () => {
    const titleEl = document.querySelector("h2") || document.querySelector(".contest-title");
    return titleEl ? titleEl.textContent.trim() : null;
};

const getProblemSlug = () => {
    const match = window.location.pathname.match(/tasks\/([^/]+)/);
    return match ? match[1] : null;
};

const getHandle = () => {
    const profile = document.querySelector("a[href*='/user/']");
    if (profile) {
        const match = profile.getAttribute("href").match(/user\/([^/]+)/);
        return match ? match[1] : null;
    }
    return null;
};

const hasAccepted = () => {
    const bodyText = document.body?.innerText.toLowerCase() || "";
    return bodyText.includes("accepted") || bodyText.includes("ac");
};

const hasAlreadySolved = () => {
    return document.body?.innerText.toLowerCase().includes("solved") || false;
};

const updatePopup = (accepted) => {
    if (typeof chrome === "undefined" || !chrome.runtime) return;
    const payload = {
        platform: "AtCoder",
        questionTitle: getProblemTitle(),
        problemSlug: getProblemSlug(),
        detectedAt: new Date().toISOString(),
        accepted: Boolean(accepted)
    };
    try {
        chrome.runtime.sendMessage({ type: "UPDATE_POPUP", payload });
    } catch (e) { }
};

const sendSolve = async () => {
    const payload = {
        platform: "AtCoder",
        questionTitle: getProblemTitle(),
        problemSlug: getProblemSlug(),
        handle: getHandle(),
        accepted: true
    };

    if (!payload.questionTitle) return;

    updatePopup(true);

    const key = `cc_atcoder_${payload.problemSlug || payload.questionTitle}`;
    if (sessionStorage.getItem(key)) return;

    chrome.runtime.sendMessage({
        type: "SOLVE_DETECTED",
        payload
    });
    sessionStorage.setItem(key, "1");
};

let initialCheckDone = false;

setInterval(() => {
    const accepted = hasAccepted();
    const alreadySolved = !initialCheckDone && hasAlreadySolved();

    if (accepted || alreadySolved) {
        if (alreadySolved) {
            console.log("CodeCanon: AtCoder problem was already previously solved! Syncing retroactively.");
            initialCheckDone = true;
        } else {
            console.log("CodeCanon: Success detected in AtCoder from new submission!");
        }
        sendSolve();
    } else {
        if (getProblemSlug()) {
            updatePopup(false);
            if (document.readyState === "complete") {
                initialCheckDone = true;
            }
        }
    }
}, 2000);
