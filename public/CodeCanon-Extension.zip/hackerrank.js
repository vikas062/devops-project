// hackerrank.js - Fixed for auto detection and submission
const API_URL = "http://localhost:5000/api/solve";

const getProblemTitle = () => {
  const titleEl = document.querySelector("h1") || document.querySelector(".challenge-name") || document.querySelector(".challenge-title");
  return titleEl ? titleEl.textContent.trim() : null;
};

const getProblemSlug = () => {
  const match = window.location.pathname.match(/challenges\/([^/]+)/);
  return match ? match[1] : null;
};

const getHandle = () => {
  const profile = document.querySelector("a[data-analytics='NavBarProfile']") || document.querySelector("a[href*='/profile/']");
  if (profile) {
    const match = profile.getAttribute("href").match(/profile\/([^/]+)/);
    return match ? match[1] : null;
  }
  return null;
};

const hasAccepted = () => {
  const bodyText = document.body?.innerText.toLowerCase() || "";
  return bodyText.includes("accepted") || bodyText.includes("all test cases passed") || document.querySelector(".success-indicator");
};

const hasAlreadySolved = () => {
  const solvedEl = document.querySelector(".solved-badge") || (document.body?.innerText.toLowerCase() || "").includes("you have solved this");
  return solvedEl !== null;
};

const updatePopup = (accepted) => {
  if (typeof chrome === "undefined" || !chrome.runtime) return;
  const payload = {
    platform: "HackerRank",
    questionTitle: getProblemTitle(),
    problemSlug: getProblemSlug(),
    detectedAt: new Date().toISOString(),
    accepted: Boolean(accepted)
  };
  try {
    chrome.runtime.sendMessage({ type: "UPDATE_POPUP", payload });
  } catch (e) { }
};

const sendSolve = async () => {
  const payload = {
    platform: "HackerRank",
    questionTitle: getProblemTitle(),
    problemSlug: getProblemSlug(),
    handle: getHandle(),
    accepted: true
  };

  if (!payload.questionTitle) return;

  updatePopup(true);

  const key = `cc_hackerrank_${payload.problemSlug || payload.questionTitle}`;
  if (sessionStorage.getItem(key)) return;

  chrome.runtime.sendMessage({
    type: "SOLVE_DETECTED",
    payload
  });
  sessionStorage.setItem(key, "1");
};

let initialCheckDone = false;

setInterval(() => {
  const accepted = hasAccepted();
  const alreadySolved = !initialCheckDone && hasAlreadySolved();

  if (accepted || alreadySolved) {
    if (alreadySolved) {
      console.log("CodeCanon: HackerRank problem was already previously solved! Syncing retroactively.");
      initialCheckDone = true;
    } else {
      console.log("CodeCanon: Success detected in HackerRank from new submission!");
    }
    sendSolve();
  } else {
    if (getProblemSlug()) {
      updatePopup(false);
      if (document.readyState === "complete") {
        initialCheckDone = true;
      }
    }
  }
}, 2000);